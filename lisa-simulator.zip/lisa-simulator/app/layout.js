import "./globals.css";

export const metadata = {
  title: "Lisa Simulator",
  description: "Ein Retro-Simulator-Spiel: Zuhause, Eiscafé Siena & Milans Wohnung",
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({ children }) {
  return (
    <html lang="de">
      <body>{children}</body>
    </html>
  );
}
