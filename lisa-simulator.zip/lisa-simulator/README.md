# Lisa Simulator 🎸

Ein Retro-2D-Simulator-Spiel, gebaut mit Next.js (App Router) und React.
Keine externen Grafik-Assets, keine externen Audio-Dateien – die komplette
Optik ist per CSS/Divs im Pixel-Look gebaut und die Musik wird direkt im
Browser mit der Web Audio API prozedural erzeugt (dazu unten mehr).

## Lokal starten

```bash
npm install
npm run dev
```

Dann [http://localhost:3000](http://localhost:3000) öffnen.

## Steuerung

- **Pfeiltasten / WASD** – Laufen
- **E** oder **Leertaste** – Interagieren (erscheint als Prompt, wenn man nah genug an einem Objekt/einer Person steht)
- **Music-Schalter** (oben rechts, immer sichtbar) – Musik an/aus. Im Eiscafé wird die Musik automatisch stummgeschaltet.

## Wichtiger Hinweis zur Musik

Du hattest "KI-generierte Musik" angefragt. Eine echte KI-Musikgenerierung
(z. B. per Audio-Diffusion-Modell) lässt sich nicht in einer Next.js-App im
Browser ausführen, ohne einen externen kostenpflichtigen API-Dienst
anzubinden. Da du selbst geschrieben hast, dass es "eine klassische
Videospiel-Imitation der Musik" sein soll, habe ich stattdessen eine
**prozedurale Chiptune-Engine** mit der Web Audio API gebaut (`lib/audio.js`).
Sie erzeugt live im Browser:

- eine Grunge-artige Basslinie fürs Schlafzimmer (E-Bass spielen)
- einen Loop im Straßen-/Wohnungs-Modus, der zwischen Rock-Riff,
  Electro-House-Beat und Hip-Hop-Groove wechselt

Falls du später doch echte KI-generierte Songs einbinden willst, kannst du
sie z. B. bei Suno/Udio erzeugen, als mp3 in `public/audio/` ablegen und in
`lib/audio.js` per `<audio>`-Tag statt Oszillatoren abspielen lassen.

## Struktur

- `app/` – Next.js App Router Einstieg
- `components/Game.js` – die komplette Spiellogik & alle Räume
- `lib/audio.js` – prozedurale Musik-Engine (Web Audio API)
- `app/globals.css` – Retro-Look, Farben, Pixel-Rahmen, CRT-Scanline-Effekt
