"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { getAudioEngine } from "../lib/audio";

/* ------------------------------------------------------------------ */
/* Welt-Koordinatensystem: jeder Raum benutzt dieselbe 400x240-Bühne,  */
/* nur der begehbare Bereich (bounds) und Hotspots/Exits variieren.   */
/* ------------------------------------------------------------------ */
const STAGE_W = 400;
const STAGE_H = 240;
const PLAYER_W = 20;
const PLAYER_H = 32;
const SPEED = 2.6;

const OUTFITS = {
  top: [
    { name: "Zebra-Crop-Top", color: "#141118", accent: "#f4f1e8" },
    { name: "Schwarzes Leder-Top", color: "#191919", accent: "#3a3a3a" },
    { name: "Off-Shoulder Blush-Top", color: "#e7b7c9", accent: "#c98aa4" },
  ],
  bottom: [
    { name: "Tartan-Minirock", color: "#7a1f2b", accent: "#f5c451" },
    { name: "Schwarze Lederhose", color: "#141414", accent: "#2a2a2a" },
    { name: "Rostrote Cordhose (weit)", color: "#a4552b", accent: "#7c3d1c" },
  ],
  shoes: [
    { name: "Schwarze Plateau-Boots", color: "#0d0d0d" },
    { name: "Chunky Sneaker (Weiß/Silber)", color: "#e7e7e7" },
    { name: "Spitze Stiletto-Boots", color: "#2a2a2a" },
  ],
  hat: [
    { name: "Baker-Boy-Cap", color: "#4a2f66" },
    { name: "Schwarzer Beanie", color: "#111111" },
    { name: "Breitkrempiger Filzhut", color: "#5c3a21" },
  ],
  socks: [
    { name: "Netzstrümpfe", color: "#333333" },
    { name: "Geringelte Strümpfe", color: "#c94f6d" },
    { name: "Nude Strümpfe", color: "#e6c7ad" },
  ],
};

const MILAN_LINES = [
  "Lisa! Perfektes Timing, ich war gerade mitten in einem Call mit unserem Lead-Investor.",
  "Wir haben die Seed-Runde jetzt bei 2,5 Millionen geschlossen, aber die Bewertung ist noch verhandelbar.",
  "Ehrlich, mein Cap Table sieht aktuell aus wie ein Excel-Kunstwerk – zwölf SAFEs, drei Angels, ein Freund von meinem Vater.",
  "Mein Co-Founder wollte 2% mehr ESOP-Pool, ich musste ihm erklären, was Verwässerung eigentlich bedeutet.",
  "Der VC meinte gestern: 'Love the vision, but what's your moat?' – ich hab einfach 'AI' gesagt und er war zufrieden.",
  "Burn Rate ist entspannt, wir haben locker 18 Monate Runway. Solange niemand die AWS-Rechnung liest.",
  "Nächste Woche Pitch Day, Slide 7 ist reine Magie – Hockey-Stick-Wachstum, du kennst das ja.",
  "Manchmal denk ich, ich sollte auch mal über was anderes reden als Term Sheets. Aber dann klingelt wieder mein Telefon.",
  "Schön, dass du da bist. Ehrlich. Kaffee? Ich hab welchen von unserem letzten Investoren-Goodie-Bag.",
];

/* ------------------------------------------------------------------ */
/* Raum-Definitionen                                                   */
/* ------------------------------------------------------------------ */
function buildRooms(isWorking) {
  return {
    bedroom: {
      name: "Schlafzimmer",
      bg: "linear-gradient(180deg, #2a1a3d 0%, #1c1128 60%, #150c1e 100%)",
      bounds: { minX: 16, maxX: 380, minY: 70, maxY: 220 },
      decor: [
        { key: "bed", left: 3, top: 30, w: 26, h: 30, color: "#4a2f66", label: "Bett" },
        { key: "bedsheet", left: 4, top: 33, w: 24, h: 20, color: "#ff3f9e", label: "" },
        { key: "dresser", left: 82, top: 30, w: 15, h: 22, color: "#3a2650", label: "Kommode" },
        { key: "poster1", left: 20, top: 4, w: 12, h: 18, color: "#9dff5a", label: "" },
        { key: "poster2", left: 40, top: 4, w: 12, h: 18, color: "#ff5a5a", label: "" },
        { key: "rug", left: 40, top: 70, w: 24, h: 14, color: "#3a2650", label: "" },
      ],
      hotspots: [
        { id: "bass", type: "bass", x: 40, y: 150, w: 26, h: 42, label: "E-Bass spielen", color: "#f5c451" },
        { id: "mirror", type: "mirror", x: 336, y: 130, w: 26, h: 56, label: "In den Spiegel schauen", color: "#8fd3ff" },
      ],
      exits: [{ x: 170, y: 208, w: 50, h: 18, to: "hallway", entry: { x: 200, y: 40 }, label: "Zum Flur" }],
    },
    hallway: {
      name: "Flur",
      bg: "linear-gradient(180deg, #241733 0%, #1a1226 100%)",
      bounds: { minX: 100, maxX: 300, minY: 30, maxY: 210 },
      decor: [{ key: "carpet", left: 30, top: 15, w: 40, h: 70, color: "#2a1a3d", label: "" }],
      hotspots: [],
      exits: [
        { x: 178, y: 22, w: 44, h: 16, to: "bedroom", entry: { x: 190, y: 170 }, label: "Schlafzimmer" },
        { x: 92, y: 96, w: 16, h: 44, to: "kitchen", entry: { x: 300, y: 118 }, label: "Küche" },
        { x: 292, y: 96, w: 16, h: 44, to: "livingroom", entry: { x: 90, y: 118 }, label: "Wohnzimmer" },
        { x: 178, y: 196, w: 44, h: 16, to: "street", entry: { x: 55, y: 195 }, label: "Straße" },
      ],
    },
    kitchen: {
      name: "Küche",
      bg: "linear-gradient(180deg, #2c2138 0%, #1c1128 100%)",
      bounds: { minX: 20, maxX: 360, minY: 34, maxY: 210 },
      decor: [
        { key: "counter", left: 5, top: 55, w: 30, h: 40, color: "#3a2650", label: "" },
        { key: "windowframe", left: 38, top: 4, w: 16, h: 14, color: "#8fd3ff", label: "" },
      ],
      hotspots: [
        { id: "coffee", type: "coffee", x: 44, y: 60, w: 28, h: 28, label: "Kaffee trinken", color: "#a4552b" },
        { id: "window", type: "window", x: 150, y: 34, w: 60, h: 26, label: "Ans Fenster setzen", color: "#8fd3ff" },
      ],
      exits: [{ x: 340, y: 100, w: 18, h: 44, to: "hallway", entry: { x: 108, y: 118 }, label: "Zum Flur" }],
    },
    livingroom: {
      name: "Wohnzimmer",
      bg: "linear-gradient(180deg, #241a30 0%, #1a1226 100%)",
      bounds: { minX: 40, maxX: 380, minY: 34, maxY: 210 },
      decor: [
        { key: "sofa", left: 12, top: 55, w: 26, h: 20, color: "#4a2f66", label: "Sofa" },
        { key: "garden", left: 78, top: 0, w: 22, h: 100, color: "#2f6d3a", label: "Garten (sichtbar)" },
      ],
      hotspots: [],
      exits: [{ x: 40, y: 100, w: 18, h: 44, to: "hallway", entry: { x: 270, y: 118 }, label: "Zum Flur" }],
    },
    street: {
      name: "Straße",
      bg: "linear-gradient(180deg, #171022 0%, #0e0a15 100%)",
      bounds: { minX: 10, maxX: 390, minY: 70, maxY: 230 },
      decor: [
        { key: "homebuilding", left: 4, top: 40, w: 20, h: 46, color: "#3a2650", label: "Zuhause" },
        { key: "cafebuilding", left: 42, top: 40, w: 22, h: 46, color: "#7a1f2b", label: "Eiscafé Siena" },
        { key: "stationbuilding", left: 80, top: 38, w: 20, h: 48, color: "#2a2a3a", label: "Bahnstation" },
      ],
      hotspots: [],
      npcs: [{ key: "addict", left: 84, top: 78, label: "" }],
      exits: [
        { x: 30, y: 150, w: 60, h: 30, to: "hallway", entry: { x: 190, y: 160 }, label: "Zur Wohnung" },
        { x: 175, y: 150, w: 60, h: 30, to: "icecafe", entry: { x: 190, y: 150 }, label: "Zum Eiscafé Siena" },
        { x: 320, y: 150, w: 60, h: 30, to: "__train__", entry: null, label: "Zur Bahnstation" },
      ],
    },
    icecafe: {
      name: "Eiscafé Siena",
      bg: "linear-gradient(180deg, #33202a 0%, #1c1128 100%)",
      bounds: { minX: 20, maxX: 380, minY: 40, maxY: 210 },
      decor: [
        { key: "counter", left: 68, top: 12, w: 20, h: 20, color: "#7a1f2b", label: "Theke" },
        { key: "table1", left: 40, top: 62, w: 10, h: 10, color: "#4a2f66", label: "" },
        { key: "table2", left: 55, top: 55, w: 10, h: 10, color: "#4a2f66", label: "" },
      ],
      hotspots: [
        {
          id: "computer",
          type: "work-computer",
          x: 300,
          y: 60,
          w: 34,
          h: 34,
          label: isWorking ? "Feierabend machen" : "Anfangen zu arbeiten",
          color: "#9dff5a",
        },
        { id: "customer", type: "work-customer", x: 80, y: 140, w: 26, h: 34, label: "Mit Kunde sprechen", color: "#f5c451" },
      ],
      npcs: [
        { key: "cust1", left: 40, top: 62, label: "" },
        { key: "cust2", left: 55, top: 55, label: "" },
      ],
      exits: [{ x: 180, y: 196, w: 44, h: 14, to: "street", entry: { x: 200, y: 190 }, label: "Zur Straße" }],
    },
    milanhome: {
      name: "Milans Wohnung",
      bg: "linear-gradient(180deg, #1c2333 0%, #10141f 100%)",
      bounds: { minX: 30, maxX: 370, minY: 40, maxY: 210 },
      decor: [
        { key: "sofa", left: 8, top: 55, w: 26, h: 20, color: "#2a3550", label: "" },
        { key: "desk", left: 78, top: 8, w: 22, h: 14, color: "#2a3550", label: "Schreibtisch mit drei Monitoren" },
      ],
      hotspots: [{ id: "milan", type: "milan", x: 180, y: 92, w: 28, h: 40, label: "Mit Milan reden", color: "#8fd3ff" }],
      exits: [{ x: 180, y: 196, w: 44, h: 14, to: "__train_back__", entry: null, label: "Zur Bahnstation" }],
    },
  };
}

/* ------------------------------------------------------------------ */
/* Sprites                                                              */
/* ------------------------------------------------------------------ */
function LisaSprite({ outfit, isWorking, sitting, size = "small", facing = "down" }) {
  const scale = size === "big" ? 4.2 : 1;
  const w = 20 * scale;
  const h = 32 * scale;
  const top = OUTFITS.top[outfit.top];
  const bottom = OUTFITS.bottom[outfit.bottom];
  const shoes = OUTFITS.shoes[outfit.shoes];
  const hat = OUTFITS.hat[outfit.hat];
  const socks = OUTFITS.socks[outfit.socks];

  return (
    <div
      style={{
        position: "relative",
        width: w,
        height: sitting ? h * 0.75 : h,
        transition: "height 0.15s",
      }}
    >
      {/* Beine */}
      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: w * 0.18,
          width: w * 0.64,
          height: h * (sitting ? 0.18 : 0.3),
          background: socks.color,
        }}
      />
      {/* Schuhe */}
      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: w * 0.14,
          width: w * 0.72,
          height: h * 0.09,
          background: shoes.color,
          borderRadius: 2 * scale,
        }}
      />
      {/* Rock/Hose */}
      <div
        style={{
          position: "absolute",
          bottom: h * (sitting ? 0.14 : 0.24),
          left: w * 0.1,
          width: w * 0.8,
          height: h * 0.28,
          background: bottom.color,
          borderTop: `${1.5 * scale}px solid ${bottom.accent}`,
        }}
      />
      {/* Oberteil (Apron, wenn arbeitend) */}
      <div
        style={{
          position: "absolute",
          top: h * 0.32,
          left: w * 0.08,
          width: w * 0.84,
          height: h * 0.3,
          background: isWorking ? "#f4f1e8" : top.color,
          border: isWorking ? `${1 * scale}px solid #c9c2b0` : "none",
        }}
      />
      {isWorking && (
        <div
          style={{
            position: "absolute",
            top: h * 0.32,
            left: w * 0.34,
            width: w * 0.32,
            height: h * 0.28,
            background: "#e6c7ad",
            opacity: 0.5,
          }}
        />
      )}
      {/* Kopf */}
      <div
        style={{
          position: "absolute",
          top: h * 0.06,
          left: w * 0.22,
          width: w * 0.56,
          height: w * 0.56,
          background: "#f0d3ba",
          borderRadius: "50%",
        }}
      >
        {/* Muttermal */}
        <div style={{ position: "absolute", bottom: "20%", right: "18%", width: 2 * scale, height: 2 * scale, background: "#6b3f2a", borderRadius: "50%" }} />
      </div>
      {/* Haare (lang, dunkelbraun/schwarz, leicht lockig angedeutet) */}
      <div
        style={{
          position: "absolute",
          top: h * 0.02,
          left: w * 0.12,
          width: w * 0.76,
          height: h * 0.24,
          background: "#241018",
          borderRadius: "50% 50% 40% 40%",
        }}
      />
      <div style={{ position: "absolute", top: h * 0.16, left: w * 0.02, width: w * 0.2, height: h * 0.42, background: "#241018", borderRadius: "40%" }} />
      <div style={{ position: "absolute", top: h * 0.16, right: w * 0.02, width: w * 0.2, height: h * 0.42, background: "#241018", borderRadius: "40%" }} />
      {/* Hut */}
      <div
        style={{
          position: "absolute",
          top: -h * 0.02,
          left: w * 0.16,
          width: w * 0.68,
          height: h * 0.14,
          background: hat.color,
          borderRadius: "40% 40% 10% 10%",
        }}
      />
      {isWorking && (
        <div
          title="Tablett mit Eisbecher"
          style={{
            position: "absolute",
            top: h * 0.5,
            right: -w * 0.25,
            width: w * 0.3,
            height: w * 0.3,
            background: "#f4f1e8",
            borderRadius: 2,
          }}
        >
          <div style={{ position: "absolute", top: -4 * scale, left: "30%", width: "40%", height: 5 * scale, background: "#ff5a5a", borderRadius: "50%" }} />
        </div>
      )}
    </div>
  );
}

function MilanSprite() {
  const w = 22;
  const h = 34;
  return (
    <div style={{ position: "relative", width: w, height: h }}>
      <div style={{ position: "absolute", bottom: 0, left: w * 0.16, width: w * 0.68, height: h * 0.32, background: "#2a3550" }} />
      <div style={{ position: "absolute", top: h * 0.32, left: w * 0.1, width: w * 0.8, height: h * 0.32, background: "#3a4a6b" }} />
      <div style={{ position: "absolute", top: h * 0.05, left: w * 0.24, width: w * 0.52, height: w * 0.52, background: "#e6c19f", borderRadius: "50%" }} />
      <div style={{ position: "absolute", top: h * 0.0, left: w * 0.14, width: w * 0.72, height: h * 0.2, background: "#161113", borderRadius: "50% 50% 30% 30%" }} />
    </div>
  );
}

function CustomerSprite() {
  return (
    <div style={{ position: "relative", width: 18, height: 28 }}>
      <div style={{ position: "absolute", bottom: 0, left: 3, width: 12, height: 18, background: "#5c4a7a" }} />
      <div style={{ position: "absolute", top: 0, left: 4, width: 10, height: 10, background: "#e6c19f", borderRadius: "50%" }} />
    </div>
  );
}

function AddictSilhouette() {
  // Bewusst sehr reduziert & abstrakt gehalten (nur eine ruhende, angelehnte Silhouette
  // als Straßen-Atmosphäre) - keine expliziten Details.
  return (
    <div style={{ position: "relative", width: 16, height: 22, opacity: 0.8 }}>
      <div style={{ position: "absolute", bottom: 0, width: 16, height: 14, background: "#3a3a46", borderRadius: "40% 40% 20% 20%" }} />
      <div style={{ position: "absolute", top: 0, left: 3, width: 10, height: 10, background: "#5b5468", borderRadius: "50%" }} />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Haupt-Komponente                                                     */
/* ------------------------------------------------------------------ */
export default function Game() {
  const [roomId, setRoomId] = useState("bedroom");
  const [pos, setPos] = useState({ x: 200, y: 150 });
  const [mode, setMode] = useState("walk"); // walk | bass | mirror | dialogue | trainLoading
  const [musicOn, setMusicOn] = useState(true);
  const [isWorking, setIsWorking] = useState(false);
  const [outfit, setOutfit] = useState({ top: 0, bottom: 0, shoes: 0, hat: 0, socks: 0 });
  const [toast, setToast] = useState(null);
  const [dialogueIndex, setDialogueIndex] = useState(0);
  const [cakeThrow, setCakeThrow] = useState(false);
  const [activeHotspot, setActiveHotspot] = useState(null);
  const [started, setStarted] = useState(false);

  const pressedKeys = useRef(new Set());
  const posRef = useRef(pos);
  const roomIdRef = useRef(roomId);
  const modeRef = useRef(mode);
  const rafRef = useRef(null);
  const toastTimer = useRef(null);
  const engine = useRef(null);

  useEffect(() => {
    posRef.current = pos;
  }, [pos]);
  useEffect(() => {
    roomIdRef.current = roomId;
  }, [roomId]);
  useEffect(() => {
    modeRef.current = mode;
  }, [mode]);

  const rooms = buildRooms(isWorking);
  const room = rooms[roomId];

  const showToast = useCallback((msg, ms = 2200) => {
    setToast(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), ms);
  }, []);

  /* ---- Audio-Engine je nach Zustand steuern ---- */
  useEffect(() => {
    engine.current = getAudioEngine();
  }, []);

  useEffect(() => {
    const eng = engine.current;
    if (!eng) return;
    const muted = !musicOn || roomId === "icecafe";
    eng.setMuted(muted);
    if (mode === "bass") {
      eng.stopTheme();
      eng.startBassSolo();
    } else {
      eng.stopBassSolo();
      if (!muted) eng.startTheme();
      else eng.stopTheme();
    }
  }, [musicOn, roomId, mode]);

  /* ---- Tastatur ---- */
  const handleInteract = useCallback(
    (hotspot) => {
      if (!hotspot) return;
      switch (hotspot.type) {
        case "bass":
          setMode("bass");
          showToast("Lisa greift zum E-Bass... 🎸", 1600);
          break;
        case "mirror":
          setMode("mirror");
          break;
        case "coffee":
          showToast("Lisa trinkt einen Kaffee. ☕");
          break;
        case "window":
          showToast("Lisa setzt sich ans Fenster und schaut in den Garten.");
          break;
        case "work-computer":
          setIsWorking((w) => !w);
          showToast(!isWorking ? "Lisa bindet sich die Schürze um und beginnt ihre Schicht." : "Feierabend! Schürze ab.");
          break;
        case "work-customer":
          setCakeThrow(true);
          showToast("Lisa wirft dem Kunden den Kuchen ins Gesicht! 🍰", 1800);
          setTimeout(() => setCakeThrow(false), 1200);
          break;
        case "milan":
          setMode("dialogue");
          setDialogueIndex(0);
          break;
        default:
          break;
      }
    },
    [isWorking, showToast]
  );

  const handleTrainRide = useCallback((back) => {
    setMode("trainLoading");
    setTimeout(() => {
      if (back) {
        setRoomId("street");
        setPos({ x: 340, y: 190 });
      } else {
        setRoomId("milanhome");
        setPos({ x: 190, y: 150 });
      }
      setMode("walk");
    }, 5000);
  }, []);

  useEffect(() => {
    function onKeyDown(e) {
      const k = e.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", "w", "a", "s", "d"].includes(k)) {
        e.preventDefault();
      }
      pressedKeys.current.add(k);

      if (!started) {
        setStarted(true);
        engine.current && engine.current.resume();
      }

      if (k === "e" || k === " " || k === "enter") {
        e.preventDefault();
        const m = modeRef.current;
        if (m === "walk") {
          handleInteract(activeHotspotRef.current);
        } else if (m === "bass") {
          setMode("walk");
        } else if (m === "mirror") {
          setMode("walk");
        } else if (m === "dialogue") {
          setDialogueIndex((i) => {
            const next = i + 1;
            if (next >= MILAN_LINES.length) {
              setMode("walk");
              return 0;
            }
            return next;
          });
        }
      }
      if (k === "escape") {
        if (modeRef.current === "mirror" || modeRef.current === "bass") setMode("walk");
      }
    }
    function onKeyUp(e) {
      pressedKeys.current.delete(e.key.toLowerCase());
    }
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [handleInteract, started]);

  const activeHotspotRef = useRef(null);

  /* ---- Game-Loop ---- */
  useEffect(() => {
    function frame() {
      const m = modeRef.current;
      if (m === "walk") {
        const keys = pressedKeys.current;
        let dx = 0;
        let dy = 0;
        if (keys.has("arrowup") || keys.has("w")) dy -= 1;
        if (keys.has("arrowdown") || keys.has("s")) dy += 1;
        if (keys.has("arrowleft") || keys.has("a")) dx -= 1;
        if (keys.has("arrowright") || keys.has("d")) dx += 1;

        if (dx !== 0 || dy !== 0) {
          const len = Math.sqrt(dx * dx + dy * dy);
          dx = (dx / len) * SPEED;
          dy = (dy / len) * SPEED;

          const currentRoom = buildRooms(isWorking)[roomIdRef.current];
          let { x, y } = posRef.current;
          x = Math.min(Math.max(x + dx, currentRoom.bounds.minX), currentRoom.bounds.maxX - PLAYER_W);
          y = Math.min(Math.max(y + dy, currentRoom.bounds.minY), currentRoom.bounds.maxY - PLAYER_H);

          // Exit-Check
          let switched = false;
          for (const ex of currentRoom.exits) {
            if (x + PLAYER_W > ex.x && x < ex.x + ex.w && y + PLAYER_H > ex.y && y < ex.y + ex.h) {
              if (ex.to === "__train__") {
                handleTrainRide(false);
              } else if (ex.to === "__train_back__") {
                handleTrainRide(true);
              } else {
                setRoomId(ex.to);
                x = ex.entry.x;
                y = ex.entry.y;
              }
              switched = true;
              break;
            }
          }

          setPos({ x, y });
          posRef.current = { x, y };

          // aktiven Hotspot bestimmen
          let found = null;
          if (!switched) {
            for (const hs of currentRoom.hotspots) {
              const cx = x + PLAYER_W / 2;
              const cy = y + PLAYER_H / 2;
              const hcx = hs.x + hs.w / 2;
              const hcy = hs.y + hs.h / 2;
              const dist = Math.hypot(cx - hcx, cy - hcy);
              if (dist < 34) {
                found = hs;
                break;
              }
            }
          }
          activeHotspotRef.current = found;
          setActiveHotspot(found);
        }
      }
      rafRef.current = requestAnimationFrame(frame);
    }
    rafRef.current = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(rafRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isWorking, handleTrainRide]);

  /* ---- Virtuelle Steuerung (Touch) ---- */
  const vkey = (key, down) => {
    if (down) pressedKeys.current.add(key);
    else pressedKeys.current.delete(key);
  };

  const cycleOutfit = (cat, dir) => {
    setOutfit((o) => {
      const len = OUTFITS[cat].length;
      const next = (o[cat] + dir + len) % len;
      return { ...o, [cat]: next };
    });
  };

  const toggleMusic = () => {
    setMusicOn((m) => !m);
    engine.current && engine.current.resume();
  };

  return (
    <div
      style={{
        width: "100vw",
        height: "100vh",
        background: "var(--ls-bg)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        touchAction: "none",
      }}
    >
      <div className="pixel-font" style={{ color: "var(--ls-pink)", fontSize: 12, marginBottom: 10, letterSpacing: 1 }}>
        LISA SIMULATOR
      </div>

      <div
        style={{
          position: "relative",
          width: "min(94vw, 640px)",
          aspectRatio: `${STAGE_W} / ${STAGE_H}`,
          background: "#000",
          border: "4px solid var(--ls-line)",
          borderRadius: 6,
          overflow: "hidden",
          boxShadow: "0 0 0 2px #000, 0 10px 40px rgba(0,0,0,0.6)",
        }}
      >
        {/* Bühne */}
        <div style={{ position: "absolute", inset: 0, background: room.bg }}>
          {/* Deko */}
          {room.decor?.map((d) => (
            <div
              key={d.key}
              title={d.label}
              style={{
                position: "absolute",
                left: `${d.left}%`,
                top: `${d.top}%`,
                width: `${d.w}%`,
                height: `${d.h}%`,
                background: d.color,
                borderRadius: 3,
                opacity: 0.9,
              }}
            />
          ))}

          {/* NPCs (dekorativ) */}
          {room.npcs?.map((n) => (
            <div
              key={n.key}
              style={{ position: "absolute", left: `${n.left}%`, top: `${n.top}%` }}
            >
              {n.key === "addict" ? <AddictSilhouette /> : <CustomerSprite />}
            </div>
          ))}

          {/* Hotspots (dezent sichtbar) */}
          {room.hotspots.map((hs) => (
            <div
              key={hs.id}
              style={{
                position: "absolute",
                left: `${(hs.x / STAGE_W) * 100}%`,
                top: `${(hs.y / STAGE_H) * 100}%`,
                width: `${(hs.w / STAGE_W) * 100}%`,
                height: `${(hs.h / STAGE_H) * 100}%`,
                background: hs.color,
                opacity: 0.28,
                borderRadius: 4,
                border: activeHotspot?.id === hs.id ? "2px solid var(--ls-amber)" : "1px dashed rgba(255,255,255,0.3)",
              }}
            />
          ))}

          {/* Milan als NPC im Milan-Raum */}
          {roomId === "milanhome" && (
            <div style={{ position: "absolute", left: `${(180 / STAGE_W) * 100}%`, top: `${(90 / STAGE_H) * 100}%` }}>
              <MilanSprite />
            </div>
          )}

          {/* Spieler */}
          <div
            style={{
              position: "absolute",
              left: `${(pos.x / STAGE_W) * 100}%`,
              top: `${(pos.y / STAGE_H) * 100}%`,
              transform: mode === "bass" || mode === "mirror" ? "translateY(0)" : undefined,
              zIndex: 5,
            }}
          >
            <LisaSprite outfit={outfit} isWorking={isWorking} sitting={mode === "bass"} />
          </div>

          {/* Kuchen-Wurf Effekt */}
          {cakeThrow && (
            <div
              className="pixel-font"
              style={{
                position: "absolute",
                left: "20%",
                top: "40%",
                fontSize: 22,
                color: "var(--ls-amber)",
              }}
            >
              🍰💥
            </div>
          )}

          {/* Raumtitel */}
          <div
            className="pixel-font"
            style={{
              position: "absolute",
              top: 6,
              left: 8,
              fontSize: 8,
              color: "var(--ls-white)",
              opacity: 0.8,
              textShadow: "1px 1px 0 #000",
            }}
          >
            {room.name}
          </div>

          {/* Interaktions-Prompt */}
          {mode === "walk" && activeHotspot && (
            <div
              className="pixel-font"
              style={{
                position: "absolute",
                bottom: 8,
                left: "50%",
                transform: "translateX(-50%)",
                fontSize: 8,
                background: "rgba(0,0,0,0.7)",
                color: "var(--ls-amber)",
                padding: "6px 8px",
                borderRadius: 4,
                whiteSpace: "nowrap",
              }}
            >
              [E] {activeHotspot.label}
            </div>
          )}

          {/* Toast */}
          {toast && (
            <div
              style={{
                position: "absolute",
                bottom: 30,
                left: "50%",
                transform: "translateX(-50%)",
                background: "rgba(21,12,30,0.92)",
                border: "1px solid var(--ls-line)",
                color: "var(--ls-white)",
                fontSize: 16,
                padding: "6px 12px",
                borderRadius: 6,
                whiteSpace: "nowrap",
              }}
            >
              {toast}
            </div>
          )}
        </div>

        {/* CRT-Effekt */}
        <div className="crt-overlay" />
        <div className="crt-vignette" />

        {/* Music-Schalter */}
        <button
          onClick={toggleMusic}
          className="pixel-font"
          style={{
            position: "absolute",
            top: 6,
            right: 6,
            zIndex: 60,
            fontSize: 7,
            padding: "6px 8px",
            background: roomId === "icecafe" ? "#333" : musicOn ? "var(--ls-green)" : "#333",
            color: roomId === "icecafe" ? "#888" : musicOn ? "#0e0e0e" : "var(--ls-white)",
            border: "2px solid #000",
            borderRadius: 4,
            opacity: roomId === "icecafe" ? 0.6 : 1,
          }}
          disabled={roomId === "icecafe"}
          title={roomId === "icecafe" ? "Im Eiscafé ist Musik nicht erlaubt" : "Musik an/aus"}
        >
          MUSIC {roomId === "icecafe" ? "OFF" : musicOn ? "ON" : "OFF"}
        </button>

        {/* Overlay: Spiegel / Kleiderschrank */}
        {mode === "mirror" && (
          <div
            style={{
              position: "absolute",
              inset: 0,
              zIndex: 70,
              background: "rgba(10,6,15,0.94)",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              padding: 12,
            }}
          >
            <div className="pixel-font" style={{ fontSize: 9, color: "var(--ls-pink)", marginBottom: 10 }}>
              SPIEGEL
            </div>
            <div style={{ marginBottom: 12 }}>
              <LisaSprite outfit={outfit} isWorking={false} size="big" />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 6, width: "100%", maxWidth: 320 }}>
              {["top", "bottom", "shoes", "hat", "socks"].map((cat) => (
                <div
                  key={cat}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    background: "var(--ls-panel)",
                    border: "1px solid var(--ls-line)",
                    borderRadius: 4,
                    padding: "4px 8px",
                  }}
                >
                  <button onClick={() => cycleOutfit(cat, -1)} style={navBtnStyle}>
                    ◀
                  </button>
                  <span style={{ fontSize: 15, textAlign: "center", flex: 1 }}>{OUTFITS[cat][outfit[cat]].name}</span>
                  <button onClick={() => cycleOutfit(cat, 1)} style={navBtnStyle}>
                    ▶
                  </button>
                </div>
              ))}
            </div>
            <button
              className="pixel-font"
              onClick={() => setMode("walk")}
              style={{ marginTop: 16, fontSize: 8, padding: "8px 14px", background: "var(--ls-pink)", border: "none", borderRadius: 4, color: "#0e0e0e" }}
            >
              SCHLIESSEN [E]
            </button>
          </div>
        )}

        {/* Overlay: Dialog mit Milan (Animal-Crossing-Stil) */}
        {mode === "dialogue" && (
          <div
            style={{
              position: "absolute",
              left: "6%",
              right: "6%",
              bottom: "8%",
              zIndex: 70,
              background: "var(--ls-white)",
              color: "#181018",
              border: "3px solid #181018",
              borderRadius: 10,
              padding: "12px 14px",
              boxShadow: "4px 4px 0 rgba(0,0,0,0.5)",
            }}
          >
            <div style={{ fontSize: 12, fontWeight: "bold", color: "var(--ls-pink)", marginBottom: 4 }} className="pixel-font">
              MILAN
            </div>
            <div style={{ fontSize: 17, lineHeight: 1.3, minHeight: 40 }}>{MILAN_LINES[dialogueIndex]}</div>
            <div style={{ textAlign: "right", marginTop: 6 }}>
              <button
                className="pixel-font"
                onClick={() =>
                  setDialogueIndex((i) => {
                    const next = i + 1;
                    if (next >= MILAN_LINES.length) {
                      setMode("walk");
                      return 0;
                    }
                    return next;
                  })
                }
                style={{ fontSize: 8, padding: "6px 10px", background: "#181018", color: "var(--ls-white)", border: "none", borderRadius: 4 }}
              >
                WEITER ▶
              </button>
            </div>
          </div>
        )}

        {/* Overlay: Bahn-Ladebildschirm */}
        {mode === "trainLoading" && <TrainLoadingScreen />}

        {/* Bass-Hinweis */}
        {mode === "bass" && (
          <div
            className="pixel-font"
            style={{
              position: "absolute",
              bottom: 8,
              left: "50%",
              transform: "translateX(-50%)",
              fontSize: 8,
              background: "rgba(0,0,0,0.7)",
              color: "var(--ls-green)",
              padding: "6px 8px",
              borderRadius: 4,
            }}
          >
            [E] Aufhören zu spielen
          </div>
        )}
      </div>

      {/* Touch-Steuerung (D-Pad + Aktion), zusätzlich zur Tastatur */}
      <TouchControls vkey={vkey} onAction={() => {
        if (!started) {
          setStarted(true);
          engine.current && engine.current.resume();
        }
        const m = modeRef.current;
        if (m === "walk") handleInteract(activeHotspotRef.current);
        else if (m === "bass" || m === "mirror") setMode("walk");
        else if (m === "dialogue") {
          setDialogueIndex((i) => {
            const next = i + 1;
            if (next >= MILAN_LINES.length) {
              setMode("walk");
              return 0;
            }
            return next;
          });
        }
      }} />

      <div style={{ fontSize: 14, color: "#7a6f8c", marginTop: 8, textAlign: "center", maxWidth: 480 }}>
        Pfeiltasten/WASD zum Laufen · [E] / Leertaste zum Interagieren
      </div>
    </div>
  );
}

const navBtnStyle = {
  background: "var(--ls-line)",
  border: "none",
  color: "var(--ls-white)",
  fontSize: 16,
  width: 28,
  height: 28,
  borderRadius: 4,
};

function TrainLoadingScreen() {
  const [dots, setDots] = useState(1);
  useEffect(() => {
    const t = setInterval(() => setDots((d) => (d % 3) + 1), 450);
    return () => clearInterval(t);
  }, []);
  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        zIndex: 80,
        background: "#000",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <div className="pixel-font" style={{ color: "var(--ls-white)", fontSize: 11, marginBottom: 14 }}>
        FÄHRT ZUR NÄCHSTEN STATION
      </div>
      <div className="pixel-font" style={{ color: "var(--ls-green)", fontSize: 20 }}>
        {".".repeat(dots)}
      </div>
    </div>
  );
}

function TouchControls({ vkey, onAction }) {
  const btn = (key, symbol, style) => (
    <button
      onPointerDown={(e) => {
        e.preventDefault();
        vkey(key, true);
      }}
      onPointerUp={(e) => {
        e.preventDefault();
        vkey(key, false);
      }}
      onPointerLeave={() => vkey(key, false)}
      onPointerCancel={() => vkey(key, false)}
      style={{
        position: "absolute",
        width: 44,
        height: 44,
        borderRadius: 8,
        border: "2px solid #000",
        background: "var(--ls-panel)",
        color: "var(--ls-white)",
        fontSize: 18,
        touchAction: "none",
        ...style,
      }}
    >
      {symbol}
    </button>
  );
  return (
    <div style={{ position: "relative", width: "min(94vw,640px)", height: 130, marginTop: 10, display: "flex", justifyContent: "space-between", padding: "0 10px" }}>
      <div style={{ position: "relative", width: 150, height: 130 }}>
        {btn("arrowup", "▲", { left: 53, top: 0 })}
        {btn("arrowdown", "▼", { left: 53, top: 86 })}
        {btn("arrowleft", "◀", { left: 0, top: 43 })}
        {btn("arrowright", "▶", { left: 106, top: 43 })}
      </div>
      <button
        onPointerDown={(e) => {
          e.preventDefault();
          onAction();
        }}
        className="pixel-font"
        style={{
          alignSelf: "center",
          width: 70,
          height: 70,
          borderRadius: "50%",
          border: "3px solid #000",
          background: "var(--ls-pink)",
          color: "#0e0e0e",
          fontSize: 10,
          touchAction: "none",
        }}
      >
        E
      </button>
    </div>
  );
}
